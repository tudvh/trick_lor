<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('title-content', 'Đây nè'); ?>


<!-- <?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/home.css')); ?>">
<?php $__env->stopSection(); ?> -->

<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TU\xampp\htdocs\trick_lor\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>