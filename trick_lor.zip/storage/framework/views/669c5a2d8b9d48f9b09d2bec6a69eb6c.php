<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - Trick loR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('public/site/css/site.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/site/css/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/site/css/sidebar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/site/css/content.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <?php echo $__env->make('layouts/site/layoutItems/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main">
        <div class="container d-flex gap-3">
            <?php echo $__env->make('layouts/site/layoutItems/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function setHeightMainBox() {
            const headerElement = document.querySelector('header')
            const headerHeight = headerElement.offsetHeight

            const mainBox = document.querySelector('.main')
            mainBox.style.paddingTop = (headerHeight + 30) + 'px'
        }

        setHeightMainBox()
        window.addEventListener('resize', setHeightMainBox)
    </script>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH D:\TU\xampp\htdocs\Trick_loR\resources\views/layouts/site/main.blade.php ENDPATH**/ ?>