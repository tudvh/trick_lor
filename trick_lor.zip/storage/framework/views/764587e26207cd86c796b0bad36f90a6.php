<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - Trick loR Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('public/admin/css/admin.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/admin/css/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/admin/css/sidebar.css')); ?>">


    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>

    <div class="warpper">
        <?php echo $__env->make('layouts/admin/layoutItems/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layouts/admin/layoutItems/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content">
            <h1 class="title"><?php echo $__env->yieldContent('title-content'); ?></h1>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>

    <?php echo $__env->yieldContent('js'); ?>
</body>

</html><?php /**PATH D:\TU\xampp\htdocs\trick_lor\resources\views/layouts/admin/main.blade.php ENDPATH**/ ?>