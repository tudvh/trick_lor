<?php

use \App\Helpers\DateHelper;
?>

<div class="wrapper row">
    <?php $__currentLoopData = $listPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item col-12 col-sm-<?php echo e($colSm); ?> col-lg-<?php echo e($colLg); ?>">
        <a href="<?php echo e(route('site.post', ['postSlug' => $post->slug])); ?>">
            <div class="img-box">
                <img src="<?php echo e(url('public/site/img')); ?>/<?php echo e($post->thumbnail); ?>" alt="">
            </div>
            <div class="info">
                <h3 class="title"><?php echo e($post->title); ?></h3>
                <span><?php echo e(DateHelper::convertDateFormat($post->created_at)); ?></span>
                <div class="d-flex gap-2">
                    <?php $__currentLoopData = $post->codes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="icon-box">
                        <?php echo $code->language->icon; ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH D:\TU\xampp\htdocs\trick_lor\resources\views/components/list-post.blade.php ENDPATH**/ ?>