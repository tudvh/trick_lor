<!-- <?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('public/site/css/header.css')); ?>">
<?php $__env->stopSection(); ?> -->

<?php $__env->startSection('content'); ?>
<h1>Home page</h1>
<?php $__env->stopSection(); ?><?php /**PATH D:\TU\xampp\htdocs\Trick_loR\resources\views/pages/home.blade.php ENDPATH**/ ?>