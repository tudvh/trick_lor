@extends('layouts.admin.main')

@section('title', 'Dashboard')
@section('title-content', 'Đây nè')


<!-- @section('css')
<link rel="stylesheet" href="{{ url('public/site/css/home.css') }}">
@stop -->

@section('content')



@stop